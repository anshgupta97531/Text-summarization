import os
from flask import Flask, request, render_template
from transformers import T5Tokenizer, T5ForConditionalGeneration

model_t5 = "t5-small"
tokenizerT5 = T5Tokenizer.from_pretrained(model_t5)
modelT5 = T5ForConditionalGeneration.from_pretrained(model_t5)

def summarize_T5(text):
    inputs = tokenizerT5.encode(text, return_tensors="pt", max_length=512, truncation=True)
    summary_ids = modelT5.generate(inputs, max_length=150, num_beams=4, early_stopping=True)
    return tokenizerT5.decode(summary_ids[0], skip_special_tokens=True)

template_dir = os.path.abspath('./htmls')
static_folder='./static_files'

app = Flask(__name__, template_folder=template_dir, static_folder=static_folder)

@app.route('/', methods=['GET',])
def main():
    return render_template('input.html')

@app.route('/result', methods=['POST',])
def result():
    if request.method == 'POST':
        input = request.form['text']
        result = summarize_T5(input);
        return render_template('result.html', input_text = input, result = result)
    return render_template('result.html')

app.run(debug=True, port=80)
