#!/usr/bin/env python
# coding: utf-8

# # Installing and importing the Required libraries
from IPython import get_ipython

# In[6]:


# get_ipython().system('pip install rouge_score')


# # In[7]:


# get_ipython().system('pip install transformers')


# # In[8]:


# get_ipython().system('pip install sentencepiece')


# # In[9]:


# get_ipython().system('pip install bert-extractive-summarizer')




# # In[10]:


# get_ipython().system('mkdir -p ~/.kaggle')
# get_ipython().system('cp kaggle.json ~/.kaggle/')


# In[11]:


# get_ipython().system('kaggle datasets download -d gowrishankarp/newspaper-text-summarization-cnn-dailymail')


# In[35]:


#Importing the neccessary libraries
import pandas as pd
import numpy as np
import tensorflow as tf
from rouge_score import rouge_scorer
from transformers import T5Tokenizer, T5ForConditionalGeneration
import matplotlib.pyplot as plt
from summarizer import Summarizer
import warnings
warnings.filterwarnings("ignore")
from wordcloud import WordCloud


# In[13]:


# get_ipython().system('chmod 600 /root/.kaggle/kaggle.json')


# In[14]:


#Extracting from Zip file
# import zipfile
# zip_ref = zipfile.ZipFile('/content/newspaper-text-summarization-cnn-dailymail.zip','r')
# zip_ref.extractall('/content')
# zip_ref.close()


# In[15]:


#Reading the trainin, validation and testing file
train_data = pd.read_csv("./content/cnn_dailymail/train.csv")
val_data = pd.read_csv("./content/cnn_dailymail/validation.csv")
test_data = pd.read_csv("./content/cnn_dailymail/test.csv")


# # Basic Data Intro and Preprocessing

# In[16]:


train_data.head()


# In[17]:


#Removing the id column
train_data = train_data[['article','highlights']]
val_data = val_data[['article','highlights']]
test_data = test_data[['article','highlights']]


# In[18]:


print("The shape of training set is : " , train_data.shape)
print("The shape of validation set is : ",val_data.shape)
print("The shape of test set is : ",test_data.shape)


# In[19]:


#Analyzing the first Article and its highlight
print(val_data['article'][0])
print(val_data['highlights'][0])


# # Cleaning Data
# 
# ### 1) - Removing \n (newline character) from the articles and highlights.
# ### 2) - Replacing all short words like (I'll = I will) from articles and highlights.
# ### 3) - Removing all stop words (Example - 'the' , 'an' , 'a') from articles and highlights.
# 

# In[20]:


#Removing \n from text
def removen(text):
  new_string = text.replace('\n','')
  return new_string


# In[21]:


#For training set
for i in range(train_data.shape[0]):
  train_data.at[i,'article'] = removen(train_data.at[i,'article'])
for i in range(train_data.shape[0]):
  train_data.at[i,'highlights'] = removen(train_data.at[i,'highlights'])


# In[22]:


#for validation set
for i in range(val_data.shape[0]):
  val_data.at[i,'article'] = removen(val_data.at[i,'article'])
for i in range(val_data.shape[0]):
  val_data.at[i,'highlights'] = removen(val_data.at[i,'highlights'])


# In[23]:


#For test set
for i in range(test_data.shape[0]):
  test_data.at[i,'article'] = removen(test_data.at[i,'article'])
for i in range(test_data.shape[0]):
  test_data.at[i,'highlights'] = removen(test_data.at[i,'highlights'])


# In[75]:


#Replacing the short words with actual words
short_words = {
"aren't": "are not",
"can't": "cannot",
"could've": "could have",
"couldn't": "could not",
"didn't": "did not",
"doesn't": "does not",
"don't": "do not",
"hadn't": "had not",
"hasn't": "has not",
"haven't": "have not",
"he'd've": "he would have",
"he'll": "he will",
"he's": "he is",
"how'd": "how did",
"how'll": "how will",
"i'll": "I will",
"i'm": "I am",
"i've": "I have",
"isn't": "is not",
"it's": "it has / it is",
"let's": "let us",
"ma'am": "madam",
"mayn't": "may not",
"might've": "might have",
"mightn't": "might not",
"must've": "must have",
"mustn't": "must not",
"needn't": "need not",
"oughtn't": "ought not",
"shan't": "shall not",
"shan't've": "shall not have",
"should've": "should have",
"shouldn't": "should not",
"they're": "they are",
"they've": "they have",
"to've": "to have",
"wasn't": "was not",
"we'll": "we will",
"we're": "we are",
"we've": "we have",
"weren't": "were not",
"will've": "will have",
"won't": "will not",
"won't've": "will not have",
"would've": "would have",
"wouldn't": "would not",
"you're": "you are",
"you've": "you have"
}


# In[76]:


def shorttolong(text):
  for word in text.split():
    if word in short_words:
      text = text.replace(word,short_words[word])
  return text


# In[77]:


#Replacing short words for all training, validation and test set
for i in range(train_data.shape[0]):
  train_data.at[i,'article'] = shorttolong(train_data.at[i,'article'])
for i in range(val_data.shape[0]):
  val_data.at[i,'article'] = shorttolong(val_data.at[i,'article'])
for i in range(test_data.shape[0]):
  test_data.at[i,'article'] = shorttolong(test_data.at[i,'article'])
for i in range(train_data.shape[0]):
  train_data.at[i,'highlights'] = shorttolong(train_data.at[i,'highlights'])
for i in range(val_data.shape[0]):
  val_data.at[i,'highlights'] = shorttolong(val_data.at[i,'highlights'])
for i in range(test_data.shape[0]):
  test_data.at[i,'highlights'] = shorttolong(test_data.at[i,'highlights'])


# In[28]:


#Removing stop words
from gensim.parsing.preprocessing import remove_stopwords
def removestopwords(text):
  new_text = remove_stopwords(text)
  return new_text


# In[81]:


#Removing stopwords from all training , validationand test set"
for i in range(train_data.shape[0]):
  train_data.at[i,'article'] = removestopwords(train_data.at[i,'article'])
for i in range(val_data.shape[0]):
  val_data.at[i,'article'] = removestopwords(val_data.at[i,'article'])
for i in range(test_data.shape[0]):
  test_data.at[i,'article'] = removestopwords(test_data.at[i,'article'])
for i in range(train_data.shape[0]):
  train_data.at[i,'highlights'] = removestopwords(train_data.at[i,'highlights'])
for i in range(val_data.shape[0]):
  val_data.at[i,'highlights'] = removestopwords(val_data.at[i,'highlights'])
for i in range(test_data.shape[0]):
  test_data.at[i,'highlights'] = removestopwords(test_data.at[i,'highlights'])


# In[82]:


text = ""
for i in range(5):
  text += val_data.at[i,'article']


# # Analysing the dataset
# 
# ## 1) Creating a wordcloud of the top 5 articles
# ## 2) Creating a word cloud of the top 5 highlights
# ## 3) Visualizing number of words in top 3 articles and highlights

# In[83]:


#Generating a word cloud with top 5 articles
wordcloud = WordCloud(
    width = 2000,
    height = 1000,
    background_color="salmon",
    colormap = "Pastel2"
).generate(text)
plt.imshow(wordcloud)
plt.show()


# In[50]:


text = ""
for i in range(5):
  text += val_data.at[i,'highlights']


# In[51]:


#Generating word cloud with top 5 highlights
wordcloud = WordCloud(
    width = 2000,
    height = 1000,
    background_color="orange",
    colormap = "Pastel2"
).generate(text)
plt.imshow(wordcloud)
plt.show()


# In[20]:


#Analysing count of words for article and highlights
def countwords(text):
  countnowords = len(text.split())
  return countnowords
for i in range(5):
  print("Number of words in article are : " , countwords(val_data['article'][i]))
  print("Number of words in highlights are : " , countwords(val_data['highlights'][i]))


# In[21]:


Data = ['First article', 'Second article' , 'Third article']

# Value of article and highlight length
article_length = [countwords(val_data['article'][0]) , countwords(val_data['article'][1]) , countwords(val_data['article'][2])]
highlights_length = [countwords(val_data['highlights'][0]) , countwords(val_data['highlights'][1]) , countwords(val_data['highlights'][2])]

# Bar width
bar_width = 0.3

# X-axis positions for the bars
x_positions = np.arange(len(Data))

# Create bar graphs
plt.bar(x_positions - bar_width, article_length, width=bar_width, label='Number of words in article')
plt.bar(x_positions, highlights_length, width=bar_width, label=' Number of words in highlights')
# Add labels, title, and legend
plt.xlabel('Article')
plt.ylabel('Word Number')
plt.title('Comparison of words in article and highlights')
plt.xticks(x_positions, Data)
plt.legend()


# ## Tokenizing the Dataset

# In[86]:


#Tokenizing the Dataset
model_t5 = "t5-small"
tokenizerT5 = T5Tokenizer.from_pretrained(model_t5)
modelT5 = T5ForConditionalGeneration.from_pretrained(model_t5)


# In[85]:


#Considering 2K Samples for training
training_data = train_data.sample(n = 2000)


# # Train model ▶
# ### First Training the Bert model.
# ### Secondly Training the T5 model.

# In[87]:


#Defining the bert model
def summarize_Bert(text):
    bert_model = Summarizer()
    bert_summary = ''.join(bert_model(text, min_length=100))
    return bert_summary


# In[ ]:


#Summarizing the text bert model
summary_bert = []
for reference in training_data['article']:
  candidate_summary_bert = summarize_Bert(reference)
  summary_bert.append(candidate_summary_bert)


# In[93]:


#Calculating the rouge score

rougeT = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)


# In[ ]:


training_data_highlight = training_data['highlights'].tolist()


# In[ ]:


for i in range(training_data.shape[0]):
  scoresBert = rougeT.score(summary_bert[i], training_data_highlight[i])


# In[ ]:


scoresBert


# In[88]:


#Defining the T5 model
def summarize_T5(text):
    inputs = tokenizerT5.encode(text, return_tensors="pt", max_length=512, truncation=True)
    summary_ids = modelT5.generate(inputs, max_length=150, num_beams=4, early_stopping=True)
    return tokenizerT5.decode(summary_ids[0], skip_special_tokens=True)


# In[ ]:


#Summarizing the text using T5 model
summary_T5 = []
for reference in training_data['article']:
  candidate_summary_T5 = summarize_T5(reference)
  summary_T5.append(candidate_summary_T5)


# In[ ]:


for i in range(training_data.shape[0]):
  scoresT5 = rougeT.score(summary_T5[i],training_data_highlight[i])


# In[ ]:


scoresT5


# # Validating the model
# 
# ---
# 
# 

# In[101]:


#Considering 100 samples for validating
val_data = val_data.sample(n=100 , ignore_index=True , replace = True)
val_data.shape


# In[91]:


#Validating the bert model
summary_bert_val = []
for reference in val_data['article']:
  candidate_summary_bert = summarize_Bert(reference)
  summary_bert_val.append(candidate_summary_bert)


# In[94]:


for i in range(val_data.shape[0]):
  scoresBertval = rougeT.score(summary_bert_val[i],val_data['highlights'][i])
scoresBertval


# In[95]:


def summarize_T5(text):
    inputs = tokenizerT5.encode(text, return_tensors="pt", max_length=512, truncation=True)
    summary_ids = modelT5.generate(inputs, max_length=150, num_beams=4, early_stopping=True)
    return tokenizerT5.decode(summary_ids[0], skip_special_tokens=True)


# In[96]:


#Validating the T5 model
summary_T5_val = []
for reference in val_data['article']:
  candidate_summary_T5 = summarize_T5(reference)
  summary_T5_val.append(candidate_summary_T5)


# In[97]:


for i in range(val_data.shape[0]):
  scoresT5val = rougeT.score(summary_T5_val[i],val_data['highlights'][i])
scoresT5val


# In[98]:


# Model names
models = ['Bert', 'T5']

# Values for each metric
precision_values = [scoresBertval['rouge1'].precision, scoresT5val['rouge1'].precision]
recall_values = [scoresBertval['rouge1'].recall, scoresT5val['rouge1'].recall]
fmeasure_values = [scoresBertval['rouge1'].fmeasure, scoresT5val['rouge1'].fmeasure]

# Bar width
bar_width = 0.2

# X-axis positions for the bars
x_positions = np.arange(len(models))

# Create bar graphs
plt.bar(x_positions - bar_width, precision_values, width=bar_width, label='Precision')
plt.bar(x_positions, recall_values, width=bar_width, label='Recall')
plt.bar(x_positions + bar_width, fmeasure_values, width=bar_width, label='F1-score')

# Add labels, title, and legend
plt.xlabel('Models')
plt.ylabel('Metric Value')
plt.title('Comparison of ROUGE-1 for Different Models')
plt.xticks(x_positions, models)
plt.legend()

# Show the graph
plt.show()


# In[99]:


# Model names
models = ['Bert', 'T5']

# Values for each metric
precision_values = [scoresBertval['rouge2'].precision, scoresT5val['rouge2'].precision]
recall_values = [scoresBertval['rouge2'].recall, scoresT5val['rouge2'].recall]
fmeasure_values = [scoresBertval['rouge2'].fmeasure, scoresT5val['rouge2'].fmeasure]

# Bar width
bar_width = 0.2

# X-axis positions for the bars
x_positions = np.arange(len(models))

# Create bar graphs
plt.bar(x_positions - bar_width, precision_values, width=bar_width, label='Precision')
plt.bar(x_positions, recall_values, width=bar_width, label='Recall')
plt.bar(x_positions + bar_width, fmeasure_values, width=bar_width, label='F1-score')

# Add labels, title, and legend
plt.xlabel('Models')
plt.ylabel('Metric Value')
plt.title('Comparison of ROUGE-2 for Different Models')
plt.xticks(x_positions, models)
plt.legend()

# Show the graph
plt.show()


# In[100]:


# Model names
models = ['Bert', 'T5']

# Values for each metric
precision_values = [scoresBertval['rougeL'].precision, scoresT5val['rougeL'].precision]
recall_values = [scoresBertval['rougeL'].recall, scoresT5val['rougeL'].recall]
fmeasure_values = [scoresBertval['rougeL'].fmeasure, scoresT5val['rougeL'].fmeasure]

# Bar width
bar_width = 0.2

# X-axis positions for the bars
x_positions = np.arange(len(models))

# Create bar graphs
plt.bar(x_positions - bar_width, precision_values, width=bar_width, label='Precision')
plt.bar(x_positions, recall_values, width=bar_width, label='Recall')
plt.bar(x_positions + bar_width, fmeasure_values, width=bar_width, label='F1-score')

# Add labels, title, and legend
plt.xlabel('Models')
plt.ylabel('Metric Value')
plt.title('Comparison of Rouge-L for Different Models')
plt.xticks(x_positions, models)
plt.legend()

# Show the graph
plt.show()


# In[ ]:




