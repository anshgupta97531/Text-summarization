step 1 =>
please download the dataset from this url
https://www.kaggle.com/datasets/gowrishankarp/newspaper-text-summarization-cnn-dailymail/

step 2 =>
extract it to the folder name 'content'


====install the dependencies=====

>run below command in the project
pip install -r requirements.txt

==== start up the server=========
>run below command to start the local server
python server.py